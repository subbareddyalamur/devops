#!/bin/bash
echo "instructions to install tomcap/app server"